const CategoryModel = require("../models/Category");

exports.getAllCategories = async (baseUrl) => {
  try {
    const categories = await CategoryModel.find();
    // Map each category to include the image path
    const categoriesWithImages = categories.map(category => {
      return {
        _id: category._id,
        description: category.description,
        // Assuming imagePath is the field where the image path is stored in CategoryModel
        imagePath: category.image,
        // Constructing the imageUrl using the provided baseUrl
        imageUrl: `${baseUrl}/${category.image}`
      };
    });
    return categoriesWithImages;
  } catch (error) {
    throw new Error(`Error fetching categories: ${error.message}`);
  }
};

exports.createCategory = async (categoryData, image) => {
  try {
  
    const newCategory = new CategoryModel({
      description: categoryData.description,
      image: image ? image.filename : undefined, // Save the path of the uploaded image
      stories: categoryData.stories || [],
    });
    await newCategory.save();
    return newCategory;
  } catch (error) {
    // Handle error appropriately
    console.error("Error creating category:", error);
    throw error;
  }
};


exports.editCategory = async (categoryId, categoryData, image) => {
  try {
    const updatedCategory = await CategoryModel.findByIdAndUpdate(
      categoryId,
      {
        description: categoryData.description,
        image: image && image.filename,
        stories: categoryData.stories || [],
      },
      { new: true }
    );
    return updatedCategory;
  } catch (error) {
    console.error("Error editing category:", error);
    throw error;
  }
};