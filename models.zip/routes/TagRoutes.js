const express = require("express");

const {
  getAllTags,
  createTag,
  editTag,
} = require("../controllers/TagController");

const router = express.Router();


// Route for getting all categories and creating a new category
router
  .route("/")
  .get(getAllTags)
  .post(createTag); // Use Multer middleware for 'image' field

router.put("/:id", editTag);
module.exports = router;
